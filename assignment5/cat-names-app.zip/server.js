const express = require('express');
const http = require('http');
const fs = require('fs');
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const port = 3000;

app.use(express.json());
app.use(express.static('public'));

app.post('/add-cat', (req, res) => {
  const { name } = req.body;
  fs.appendFile('cat-names.txt', `${name}\n`, (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('An error occurred on the server.');
    }
    io.emit('cat name', name);
    res.send('Cat name saved successfully!');
  });
});

app.get('/cats', (req, res) => {
  fs.readFile('cat-names.txt', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send('An error occurred on the server.');
    }
    res.send(data.split('\n').filter(Boolean));
  });
});

io.on('connection', (socket) => {
  console.log('a user connected');
  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

server.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});