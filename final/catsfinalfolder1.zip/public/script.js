function toggleGallery() {
    var content = document.querySelector("#gallery .content");
    if (content.style.display === "none") {
        content.style.display = "block";
    } else {
        content.style.display = "none";
    }
}


function loadGuestbookEntries() {
    fetch('/get-guestbook-entries')
        .then(response => response.text())
        .then(data => {
            document.getElementById('guestbook-messages').textContent = data;
        })
        .catch(err => console.error('Failed to load guestbook entries', err));
}

window.addEventListener('DOMContentLoaded', (event) => {
    loadGuestbookEntries();
});
let currentSlide = 0;
const slides = [
    { src: "cat4.jpg", text: "Muffin was always a bit of a biter. Not to much effect as she had no teeth, more like a gnawer at best, but she always loved to lick people." },
    { src: "cat5.jpg", text: "Ever since we first got her, all she ever did was sleep. She slept so much sometimes, upwards of 8 hours. She had to rest to make sure she had the energy to lick people later." },
    { src: "cat6.jpg", text: "This photo is a great example of her silly eyes! I always liked to say she was an apex predator, due to her being able to see two prey at the same time." },
    { src: "cat7.jpg", text: "Her and Zelda, my older brothers cat. Zelda was very shy, and only ever liked Muffin, but to be fair everyone liked Muffin." },
    { src: "cat8.jpg", text: "One of my favorite pics of her. At work we were given these to put on our cats heads. Muffin made a beautiful princess." },
    { src: "cat9.jpg", text: "Muffin and Clover! As you probably remember, Clover is the one eyed cat about 10 pounds heavier than Muff, but she still got licked all the same." },
    { src: "cat10.jpg", text: "Despite all the weirdness of Muffin, her cat roots still showed up sometimes. She loved laying in high places, but would often fall very quickly." },
    { src: "cat11.jpg", text: "I love this photo. I always associate it with a looney toon scream, but in reality she is just yawning. Take a look at those teeth! Or lack thereof." },
    { src: "cat12.jpg", text: "My sweet baby in the sun. I hope wherever she is there's plenty of it there for her." },
    { src: "cat17.jpg", text: "A hard one to look at. The last photo ever taken of her. Even in her final moments, she tried to lick my hand. It never gets easier, but we as people grow to acommodate for grief." },
];
const slidesContainer = document.querySelector('.carousel-slides');
const storyText = document.getElementById('photo-story-text');

function createSlide(slide) {
    const img = document.createElement('img');
    img.src = slide.src;
    img.alt = 'Photo story';
    img.classList.add('fade');
    return img;
}

function displaySlides() {
    slidesContainer.innerHTML = '';
    const slide = createSlide(slides[currentSlide]);
    slidesContainer.appendChild(slide);
    storyText.textContent = slides[currentSlide].text;
}

function changeSlide(direction) {
    currentSlide += direction;
    if (currentSlide >= slides.length) currentSlide = 0;
    if (currentSlide < 0) currentSlide = slides.length - 1;
    displaySlides();
}

window.addEventListener('DOMContentLoaded', (event) => {
    loadGuestbookEntries();
    displaySlides();
});
const timelineEvents = [
    {
        date: "2011",
        content: "This is the year we got Muffin. As you've probably heard me say a million times, she was dropped on our neighbors roof. The dogs there didn't like Muffin much, so we decided to adopt her. It was the best decision I have ever made. Fun fact: My name choices were between Kiwi and Muffin! "
    },
    {
        date: "2014",
        content: "This is the year she lost her teeth. They just started popping out, and so we got them all removed. It was honestly quite scary to say the least."
    },
    {
        date: "2016",
        content: "She got a friend! This isn't her first friend, as she had one when we first adopted her named Sophie, unfortunately Sophie was hit a few months later by a car. This time we got Zelda, one of Muffins best friends."
    },
    {
        date: "2018",
        content: "I had Muff for a while at this point. She always slept with me, and was constantly on my lap. She didn't weigh much so I never minded much."
    },
    {
        date: "2019",
        content: "Covid hit! Muffin couldn't be happier. I'm home all the time to hangout with her."
    },
    {
        date: "2020",
        content: "Muffin by this point had gotten very very old. Vets estimated she was already around 7 when we got her, and she would have been 16 here. I had to help her up the stairs, though she could do it herself. But she was my princess, and I would have done it for the rest of my life if I could."
    },
    {
        date: "2022",
        content: "Her weight fluctuates around. 5 pounds to 4 pounds then back again. Sleepy all the time, but still so full of love. She would use up all her energy for the day just licking people and getting on their laps."
    },
    {
        date: "2023",
        content: "Chronic respiratory issues happened this year. The vets couldn't figure it out. I think I ended up taking her to 6 different vets. They were stumped. It did end up improving by the end of the year though, but she had a hard time breathing."
    },
    {
        date: "2024",
        content: "The year we had to put her down. She had gotten too weak to eat, to drink, and I knew it was her time. It doesn't make it any easier. Sometimes I wonder if I made the right choice, but I know it was her time. I would have given anything to have her a little longer."
    },
    {
        date: "2024",
        content: "An update to current times. Two days ago I had a dream. Muffin and I laid in her favorite spot on the couch. My dreams have never been realistic, and I have never been able to be conscious in them, but this one time I was. I looked at her, pet her, and told her I knew she was gone, but I was happy to have this time to visit her, even if it was only a dream. She rolled over, let me pet her stomach, licked my hand, and I woke up, happy to have seen her one last time."
    },
];

document.addEventListener('DOMContentLoaded', () => {
    const timelineDates = document.querySelectorAll('.timeline-dates button');
    const eventDetails = document.querySelector('.event-details');

    timelineDates.forEach(button => {
        button.addEventListener('click', function() {
            const eventIndex = this.getAttribute('data-date');
            const event = timelineEvents[eventIndex];
            eventDetails.innerHTML = `<h3>${event.date}</h3><p>${event.content}</p>`;
        });
    });
});
