const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));y

const guestbookFilePath = path.join(__dirname, 'guestbook.txt');

app.post('/submit-guestbook-entry', (req, res) => {
    const { name, message } = req.body;
    const entry = `Name: ${name}, Message: ${message}\n`;

    fs.appendFile(guestbookFilePath, entry, (err) => {
        if (err) {
            console.error('Failed to save the guestbook entry', err);
            res.status(500).send('Error saving your entry. Please try again later.');
            return;
        }
        console.log('Saved guestbook entry');
        res.redirect('/');
    });
});

app.get('/get-guestbook-entries', (req, res) => {
    fs.readFile(guestbookFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Failed to read the guestbook entries', err);
            res.status(500).send('Error reading the guestbook entries.');
            return;
        }
        res.send(data);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
